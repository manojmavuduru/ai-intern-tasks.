# Task 1 — Rule-Based Chatbot

A simple chatbot that responds to user input using **predefined rules**
(regex pattern matching) rather than machine learning. This project
builds intuition for conversation flow and basic NLP before tackling
ML-based dialogue systems.

## How it works

1. User input is checked against a list of **rules**, where each rule
   has one or more regex patterns and a list of candidate responses.
2. On the first matching pattern, a response is randomly chosen from
   that rule's response list.
3. Patterns can capture groups (e.g. a name) and inject them into the
   response using `{0}` placeholders.
4. If no rule matches, a fallback response is returned.

Rules are defined in [`rules.json`](rules.json) and can be edited or
extended without touching the code — or you can rely on the built-in
defaults in `chatbot.py`.

## Project structure

```
task1-rule-based-chatbot/
├── chatbot.py          # Core chatbot engine (CLI runnable)
├── app.py              # Streamlit web UI
├── rules.json          # Editable rule set
├── test_chatbot.py     # Unit tests
└── requirements.txt
```

## Running it

### Command line
```bash
python chatbot.py
```

### Web UI (Streamlit)
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Running tests
```bash
python -m unittest test_chatbot.py -v
```

## Example interaction
```
RuleBot: Hello! Type 'bye' to exit.
You: hi
RuleBot: Hi there! What can I do for you?
You: my name is Alex
RuleBot: Nice to meet you, Alex!
You: tell me a joke
RuleBot: Why do programmers prefer dark mode? Because light attracts bugs!
You: bye
RuleBot: Goodbye! Have a great day.
```

## Possible extensions
- Swap regex rules for an **intent classifier** (e.g. scikit-learn `TfidfVectorizer` + `LogisticRegression`) to make matching more robust.
- Add **context/state tracking** for multi-turn conversations (e.g. remembering a user's name across the session — partially implemented).
- Integrate spaCy for proper entity extraction (dates, names, locations) instead of regex groups.
- Connect to a real LLM API as a fallback when no rule matches, for a hybrid rule-based + generative chatbot.

## Concepts demonstrated
Pattern matching, intent recognition, basic dialogue management, regex, simple state handling.
