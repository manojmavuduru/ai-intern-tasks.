"""
Streamlit web interface for the Rule-Based Chatbot.
Run with: streamlit run app.py
"""

import streamlit as st
from chatbot import RuleBasedChatbot

st.set_page_config(page_title="Rule-Based Chatbot", page_icon="🤖")

st.title("🤖 Rule-Based Chatbot")
st.caption("A simple chatbot powered by regex pattern matching and if-else logic.")

if "bot" not in st.session_state:
    st.session_state.bot = RuleBasedChatbot()
if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! Type something to get started. Try 'hello', 'tell me a joke', or 'what time is it'."}
    ]

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.write(msg["content"])

user_input = st.chat_input("Type your message...")

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.write(user_input)

    response = st.session_state.bot.get_response(user_input)
    st.session_state.messages.append({"role": "assistant", "content": response})
    with st.chat_message("assistant"):
        st.write(response)

with st.sidebar:
    st.header("About")
    st.write(
        "This chatbot identifies intents using regular expression "
        "pattern matching, then returns a response associated with "
        "the matched rule. No machine learning is used here — it's "
        "a great way to understand conversation flow before moving "
        "to ML/NLP based chatbots."
    )
    st.write("**Try asking about:**")
    st.markdown("- Greetings (`hello`, `hi`)\n- `time` / `date`\n- A `joke`\n- `help`")
    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.rerun()
