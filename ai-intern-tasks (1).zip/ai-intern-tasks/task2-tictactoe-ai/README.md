# Task 2 — Tic-Tac-Toe AI (Minimax + Alpha-Beta Pruning)

An AI agent that plays a **mathematically unbeatable** game of
Tic-Tac-Toe using the **Minimax algorithm**, optionally accelerated
with **Alpha-Beta Pruning**. This project demonstrates adversarial
search and game theory fundamentals.

## How it works

- **Minimax** recursively explores every possible sequence of future
  moves, assuming the AI always maximizes its score and the opponent
  always minimizes it (i.e., plays optimally against the AI).
- Terminal states are scored: AI win = `+10 - depth`, human win =
  `depth - 10`, draw = `0`. Subtracting/adding depth makes the AI
  prefer **faster wins** and **slower losses**.
- **Alpha-Beta Pruning** skips branches of the search tree that
  cannot influence the final decision, cutting down the number of
  positions evaluated significantly without changing the result.

Because Tic-Tac-Toe is a "solved" game, an agent using full minimax
search can never lose — it will always win or draw.

## Project structure

```
task2-tictactoe-ai/
├── tictactoe.py        # Game logic + Minimax/Alpha-Beta agent (CLI runnable)
├── app.py              # Streamlit interactive web UI
├── test_tictactoe.py   # Unit tests, incl. proof the AI never loses
└── requirements.txt
```

## Running it

### Command line
```bash
python tictactoe.py
```

### Web UI (Streamlit) — recommended for demos
```bash
pip install -r requirements.txt
streamlit run app.py
```
The web UI includes a toggle for Alpha-Beta Pruning and shows how
many positions were evaluated per move, so you can directly observe
the speed-up pruning provides.

## Running tests
```bash
python -m unittest test_tictactoe.py -v
```
Includes a test that simulates a full game and asserts the AI never
loses, plus a test confirming pruning produces the same quality of
decision as plain minimax (just faster).

## Possible extensions
- Generalize the board to **N x N** with a configurable win condition.
- Add a **difficulty setting** by limiting search depth or adding randomness, so beginners can actually win sometimes.
- Visualize the search tree (e.g., with Graphviz) to explain *why* the AI picked a move.
- Extend to **Connect Four** — same algorithm, larger search space, good showcase of pruning's value.

## Concepts demonstrated
Game theory, adversarial search, recursion, tree pruning, time-complexity analysis.
