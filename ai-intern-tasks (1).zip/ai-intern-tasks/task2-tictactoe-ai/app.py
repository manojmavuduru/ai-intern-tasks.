"""
Streamlit web interface for Tic-Tac-Toe AI.
Run with: streamlit run app.py
"""

import streamlit as st
from tictactoe import TicTacToe, MinimaxAgent, HUMAN, AI, EMPTY

st.set_page_config(page_title="Tic-Tac-Toe AI", page_icon="❌")

st.title("❌⭕ Unbeatable Tic-Tac-Toe AI")
st.caption("Powered by the Minimax algorithm with Alpha-Beta Pruning. Best you can do is draw!")

if "game" not in st.session_state:
    st.session_state.game = TicTacToe()
    st.session_state.agent = MinimaxAgent(use_pruning=True)
    st.session_state.status = "playing"
    st.session_state.nodes = 0

game: TicTacToe = st.session_state.game
agent: MinimaxAgent = st.session_state.agent

with st.sidebar:
    st.header("Settings")
    use_pruning = st.checkbox("Use Alpha-Beta Pruning", value=True)
    agent.use_pruning = use_pruning
    if st.button("🔄 Restart game"):
        st.session_state.game = TicTacToe()
        st.session_state.status = "playing"
        st.session_state.nodes = 0
        st.rerun()

    st.divider()
    st.write("**Last AI move stats**")
    st.metric("Positions evaluated", st.session_state.nodes)

    st.divider()
    st.write(
        "Minimax explores every possible future game state to find the "
        "move that guarantees the best outcome assuming the opponent "
        "also plays optimally. Alpha-Beta Pruning skips branches that "
        "can't possibly change the result, making the search faster "
        "without changing the outcome."
    )


def check_game_over():
    winner = game.winner()
    if winner == HUMAN:
        st.session_state.status = "human_win"
    elif winner == AI:
        st.session_state.status = "ai_win"
    elif game.is_full():
        st.session_state.status = "draw"


def human_move(idx):
    if st.session_state.status != "playing" or game.board[idx] != EMPTY:
        return
    game.make_move(idx, HUMAN)
    check_game_over()
    if st.session_state.status == "playing":
        ai_move, nodes = agent.best_move(game)
        game.make_move(ai_move, AI)
        st.session_state.nodes = nodes
        check_game_over()


# Render board
cols = st.columns(3)
symbol_color = {"X": "🔵", "O": "🔴"}
for i in range(9):
    col = cols[i % 3]
    label = game.board[i] if game.board[i] != EMPTY else " "
    if col.button(label if label != " " else "⬜", key=f"cell_{i}", use_container_width=True):
        human_move(i)
        st.rerun()

st.write("")

status_messages = {
    "playing": "🎮 Your turn — you are **X**.",
    "human_win": "🎉 You won! (Impressive — Minimax should never lose.)",
    "ai_win": "🤖 AI wins!",
    "draw": "🤝 It's a draw!",
}
st.subheader(status_messages[st.session_state.status])
