# Task 3 — Image Captioning AI

Combines **computer vision** and **NLP** to automatically generate
natural-language captions for images, using the classic
encoder–decoder ("Show and Tell") architecture:

- **Encoder**: a pre-trained CNN (**ResNet-50** or **VGG16**, your choice) extracts a fixed-length feature vector from the image.
- **Decoder**: an **LSTM** generates the caption one word at a time, conditioned on that feature vector.

## Project structure

```
task3-image-captioning/
├── feature_extractor.py   # CNN encoder (ResNet50/VGG16) — extract & cache image features
├── vocabulary.py          # Build word<->index mapping from captions
├── dataset.py             # PyTorch Dataset pairing features with tokenized captions
├── model.py               # LSTM decoder (training forward pass + greedy generation)
├── train.py                # End-to-end training script
├── infer.py                # Generate a caption for a single new image
├── app.py                  # Streamlit demo UI
├── test_captioning.py      # Unit tests (vocab + model shape/behavior checks)
└── requirements.txt
```

## Why this needs a dataset to fully train

Unlike Tasks 1–2, image captioning needs a **labeled dataset of
images with captions** to train the decoder — there's no way around
that (no pretrained "caption decoder" ships in torchvision). The
encoder (ResNet/VGG) is already pretrained on ImageNet, so you only
need to train the lightweight LSTM decoder. The standard beginner
dataset is **Flickr8k** (8,000 images, 5 captions each, ~1GB).

### Getting Flickr8k
1. Download from Kaggle: search "Flickr8k Dataset" (e.g. `adityajn105/flickr8k`).
2. You'll get an `Images/` folder and a `captions.txt` file (format: `image_name,caption`).
3. Convert `captions.txt` into the JSON shape this project expects:

```python
import csv, json
from collections import defaultdict

captions_map = defaultdict(list)
with open("captions.txt") as f:
    reader = csv.reader(f)
    next(reader)  # skip header
    for image_name, caption in reader:
        captions_map[image_name].append(caption)

with open("captions.json", "w") as f:
    json.dump(captions_map, f)
```

## Running the full pipeline

```bash
pip install -r requirements.txt

# 1. Extract CNN features for every training image (one-time, can take a while on CPU)
python feature_extractor.py path/to/Flickr8k/Images --backbone resnet50 --out features.pkl

# 2. Train the LSTM decoder
python train.py --features features.pkl --captions captions.json --epochs 20

# 3. Generate a caption for a new image
python infer.py path/to/some_image.jpg --model caption_model.pt --vocab vocab.json
```

## Running the demo without training first

```bash
streamlit run app.py
```
Upload any image — if no trained model is found yet, the app falls
back to showing the **live CNN feature extraction** step (the
encoder half of the pipeline) so you can demo the working
infrastructure even before training finishes.

## Running tests
```bash
python -m unittest test_captioning.py -v
```
These tests validate the vocabulary encode/decode logic and the
decoder's forward-pass/generation shapes — they don't require a GPU
or the actual dataset.

## Possible extensions
- Swap the LSTM decoder for a **Transformer decoder** (attention over CNN feature maps, not just a single pooled vector) — closer to how modern captioning models work.
- Add **attention visualization** (show which part of the image the model "looked at" for each generated word — classic "Show, Attend and Tell" paper).
- Evaluate with **BLEU / METEOR / CIDEr** scores against held-out references.
- Use **beam search** instead of greedy decoding for better caption quality.

## Concepts demonstrated
Transfer learning, CNN feature extraction, sequence generation (RNN/LSTM), teacher forcing, encoder-decoder architectures.
