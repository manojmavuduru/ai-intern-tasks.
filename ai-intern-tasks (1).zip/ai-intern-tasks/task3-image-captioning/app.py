"""
Streamlit web interface for the Image Captioning project.
Run with: streamlit run app.py

If a trained model (caption_model.pt + vocab.json) is present, it
will generate real captions. Otherwise it demonstrates the CNN
feature-extraction step on its own, with instructions on training
the decoder.
"""

import os
import streamlit as st
from PIL import Image

st.set_page_config(page_title="Image Captioning AI", page_icon="🖼️")
st.title("🖼️ Image Captioning AI")
st.caption("CNN (ResNet-50/VGG16) feature extractor + LSTM caption decoder")

MODEL_PATH = "caption_model.pt"
VOCAB_PATH = "vocab.json"

uploaded = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])

if uploaded:
    image = Image.open(uploaded).convert("RGB")
    st.image(image, caption="Uploaded image", use_container_width=True)

    tmp_path = "uploaded_temp.jpg"
    image.save(tmp_path)

    if os.path.exists(MODEL_PATH) and os.path.exists(VOCAB_PATH):
        with st.spinner("Extracting features and generating caption..."):
            from infer import generate_caption
            caption = generate_caption(tmp_path, MODEL_PATH, VOCAB_PATH)
        st.success(f"**Caption:** {caption}")
    else:
        st.warning(
            "No trained decoder found yet (`caption_model.pt` / `vocab.json`). "
            "Showing the CNN feature-extraction step only — train the decoder "
            "(see README) to get full captions."
        )
        with st.spinner("Extracting CNN features..."):
            from feature_extractor import FeatureExtractor
            extractor = FeatureExtractor(backbone="resnet50")
            features = extractor.extract(tmp_path)
        st.write(f"Extracted a **{features.shape[0]}-dimensional** feature vector from ResNet-50.")
        st.write("Preview of the first 10 feature values:")
        st.code(str(features[:10]))

    os.remove(tmp_path)

with st.sidebar:
    st.header("Architecture")
    st.markdown(
        "1. **Encoder**: Pre-trained ResNet-50 / VGG16 (ImageNet weights) "
        "extracts a fixed-length feature vector from the image.\n"
        "2. **Decoder**: An LSTM, initialized from the image feature vector, "
        "generates the caption one word at a time.\n"
        "3. Trained with **teacher forcing** and cross-entropy loss on a "
        "captioned image dataset (e.g. Flickr8k)."
    )
    st.divider()
    st.write("See `README.md` for training instructions on your own dataset.")
