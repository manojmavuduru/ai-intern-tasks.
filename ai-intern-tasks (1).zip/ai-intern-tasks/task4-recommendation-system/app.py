"""
Streamlit web interface for the Recommendation System.
Run with: streamlit run app.py
"""

import os
import pandas as pd
import streamlit as st

from content_based import ContentBasedRecommender
from collaborative_filtering import CollaborativeFilteringRecommender
from generate_sample_data import generate_dataset

st.set_page_config(page_title="Movie Recommender", page_icon="🎬", layout="wide")
st.title("🎬 Movie Recommendation System")
st.caption("Content-based filtering + Collaborative filtering (user-based, item-based, SVD)")

DATA_DIR = "data"
if not os.path.exists(os.path.join(DATA_DIR, "movies.csv")):
    generate_dataset(out_dir=DATA_DIR)

movies = pd.read_csv(os.path.join(DATA_DIR, "movies.csv"))
ratings = pd.read_csv(os.path.join(DATA_DIR, "ratings.csv"))

cb = ContentBasedRecommender(movies)
cf = CollaborativeFilteringRecommender(ratings, movies)

tab1, tab2, tab3 = st.tabs(["🎯 Content-Based", "👥 Collaborative Filtering", "📊 Dataset"])

with tab1:
    st.subheader("Content-Based Filtering")
    st.write("Recommends movies with similar genres to ones you already like.")

    mode = st.radio("Mode", ["Similar to one movie", "Based on multiple favorites"], horizontal=True)

    if mode == "Similar to one movie":
        title = st.selectbox("Pick a movie you liked:", movies["title"].tolist())
        top_n = st.slider("Number of recommendations", 1, 10, 5, key="cb_single")
        if st.button("Get recommendations", key="cb_btn1"):
            result = cb.similar_to(title, top_n=top_n)
            st.dataframe(result, use_container_width=True)
    else:
        titles = st.multiselect("Pick a few movies you liked:", movies["title"].tolist(),
                                  default=movies["title"].tolist()[:2])
        top_n = st.slider("Number of recommendations", 1, 10, 5, key="cb_multi")
        if st.button("Get recommendations", key="cb_btn2") and titles:
            result = cb.recommend_for_user_history(titles, top_n=top_n)
            st.dataframe(result, use_container_width=True)

with tab2:
    st.subheader("Collaborative Filtering")
    method = st.radio("Method", ["User-based", "Item-based", "SVD (latent factors)"], horizontal=True)

    if method == "User-based":
        user_id = st.selectbox("Select a user:", sorted(ratings["userId"].unique()))
        top_n = st.slider("Number of recommendations", 1, 10, 5, key="ub")
        if st.button("Get recommendations", key="ub_btn"):
            st.write(f"**User {user_id}'s rated movies:**")
            rated = ratings[ratings["userId"] == user_id].merge(movies, on="movieId")[["title", "rating"]]
            st.dataframe(rated.sort_values("rating", ascending=False), use_container_width=True)
            st.write("**Recommended for them:**")
            result = cf.recommend_user_based(user_id, top_n=top_n)
            st.dataframe(result, use_container_width=True)

    elif method == "Item-based":
        title = st.selectbox("Pick a movie:", movies["title"].tolist(), key="ib_title")
        top_n = st.slider("Number of recommendations", 1, 10, 5, key="ib")
        if st.button("Get recommendations", key="ib_btn"):
            try:
                result = cf.recommend_item_based(title, top_n=top_n)
                st.dataframe(result, use_container_width=True)
            except ValueError as e:
                st.error(str(e))

    else:
        user_id = st.selectbox("Select a user:", sorted(ratings["userId"].unique()), key="svd_user")
        top_n = st.slider("Number of recommendations", 1, 10, 5, key="svd")
        if st.button("Get recommendations", key="svd_btn"):
            result = cf.recommend_svd(user_id, top_n=top_n)
            st.dataframe(result, use_container_width=True)

with tab3:
    st.subheader("Sample Dataset")
    st.write(f"**{len(movies)} movies**, **{ratings['userId'].nunique()} users**, **{len(ratings)} ratings**")
    col1, col2 = st.columns(2)
    with col1:
        st.write("Movies")
        st.dataframe(movies, use_container_width=True, height=300)
    with col2:
        st.write("Ratings (sample)")
        st.dataframe(ratings.head(20), use_container_width=True, height=300)

with st.sidebar:
    st.header("About")
    st.markdown(
        "- **Content-based**: TF-IDF over genres + cosine similarity. Works even for brand-new items (no 'cold start' problem).\n"
        "- **User-based CF**: finds users with similar taste, recommends what they liked.\n"
        "- **Item-based CF**: finds items that tend to be rated similarly.\n"
        "- **SVD**: matrix factorization to uncover latent taste dimensions.\n\n"
        "Dataset is synthetically generated with built-in 'taste clusters' "
        "(action fans, romantics, comedy fans, horror fans) so the "
        "recommendations have real signal to find. Swap in MovieLens "
        "for a production-scale version — see README."
    )
